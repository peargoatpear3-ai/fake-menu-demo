@echo off
setlocal
cd /d "%~dp0"
echo === Fake Menu Demo setup ===
echo This will try to install Gradle with Windows Package Manager (winget).
echo It does not install anything if winget is missing or the install is blocked.
where winget >nul 2>nul
if errorlevel 1 (
  echo winget was not found. Install Gradle using the official guide:
  echo https://docs.gradle.org/current/userguide/installation.html
  pause
  exit /b 1
)
where java >nul 2>nul
if errorlevel 1 (
  echo Java was not found. Minecraft 1.21.11 mod development needs JDK 21.
  echo Install a JDK 21 first, then run this file again.
  pause
  exit /b 1
)
winget install --id Gradle.Gradle -e --source winget
if errorlevel 1 echo Gradle installation may have been cancelled or blocked. Continuing to check...
echo.
echo Close and reopen this window if Gradle is not recognized yet.
gradle --version
if errorlevel 1 (
  echo Gradle is not available in this window. Reopen Command Prompt and run this file again.
  pause
  exit /b 1
)
echo.
echo Building the mod. The first build needs an internet connection to download dependencies.
gradle build
if errorlevel 1 (
  echo Build failed. Copy the full error text and ask for help fixing it.
  pause
  exit /b 1
)
echo.
echo Build finished. Look for the JAR inside build\libs\
pause
