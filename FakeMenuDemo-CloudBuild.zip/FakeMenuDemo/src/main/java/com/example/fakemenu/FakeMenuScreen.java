package com.example.fakemenu;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class FakeMenuScreen extends Screen {
    public FakeMenuScreen() { super(Component.literal("Fake Menu Demo")); }

    @Override
    protected void init() {
        int cx = this.width / 2;
        this.addRenderableWidget(net.minecraft.client.gui.components.Button.builder(
            Component.literal("Close"), button -> this.onClose())
            .bounds(cx - 50, this.height / 2 + 75, 100, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        this.renderBackground(g, mouseX, mouseY, delta);
        int cx = this.width / 2, top = Math.max(12, this.height / 2 - 100);
        int left = cx - 155, right = cx + 155;
        g.fill(left, top, right, top + 195, 0xEE111827);
        g.fill(left, top, right, top + 3, 0xFF38BDF8);
        g.drawCenteredString(this.font, "FAKE MENU DEMO", cx, top + 12, 0xFFFFFFFF);
        g.drawCenteredString(this.font, "LOCAL DEMO — NOT REAL SERVER DATA", cx, top + 29, 0xFFFFD166);
        g.drawString(this.font, "Fake Pay:       $12,500 (display only)", left + 16, top + 51, 0xFF86EFAC);
        g.drawString(this.font, "Fake Elytra:    Preview enabled", left + 16, top + 71, 0xFF93C5FD);
        g.drawString(this.font, "Fake Balance:   999,999 (display only)", left + 16, top + 91, 0xFF86EFAC);
        g.drawString(this.font, "Fake Media:     Demo badge", left + 16, top + 111, 0xFFC4B5FD);
        g.drawString(this.font, "Fake Loot Drop: Preview only", left + 16, top + 131, 0xFFFCA5A5);
        g.drawCenteredString(this.font, "Odds display: 50% / 50% (illustration only)", cx, top + 157, 0xFFFFFFFF);
        g.drawCenteredString(this.font, "No rolls, trades, commands, or real rewards.", cx, top + 174, 0xFFD1D5DB);
        super.render(g, mouseX, mouseY, delta);
    }

    @Override public boolean isPauseScreen() { return false; }
}
