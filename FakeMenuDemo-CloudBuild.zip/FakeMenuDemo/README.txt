Fake Menu Demo — Fabric / Minecraft Java 1.21.11

This is source code for a client-side visual demo. The numbers and items are fictional and only appear in the menu; this does not change server balances, send pay commands, grant items, or rig real loot.

Open menu: Right Shift (see FakeMenuClient.java).

IMPORTANT: This folder is a mod PROJECT, not a compiled .jar yet.

Build without installing Gradle on your PC (uses GitHub Actions):
1. Go to https://github.com and sign in or create an account.
2. Create a new empty repository.
3. Upload the CONTENTS of this folder to the repository (including the hidden .github folder).
4. Open the repository's Actions tab and select "Build Fabric mod". Click "Run workflow" if it hasn't started automatically.
5. When it finishes, open the workflow run and download the artifact named "fake-menu-demo-jar".
6. Extract the downloaded artifact ZIP and place the .jar file in your Minecraft instance's mods folder. Use Fabric Loader for Minecraft 1.21.11.

The GitHub workflow installs Gradle on its temporary build machine; you do not install Gradle locally. Java 21 is required for Minecraft 1.21.11.

If the workflow fails, open the build log; the source may need updating for the exact Minecraft/Fabric versions.
